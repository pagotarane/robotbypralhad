alert(arguments[0]);
