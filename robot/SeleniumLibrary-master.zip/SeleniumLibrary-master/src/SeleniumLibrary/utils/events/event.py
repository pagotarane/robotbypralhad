# Copyright 2008-2011 Nokia Networks
# Copyright 2011-2016 Ryan Tomac, Ed Manlove and contributors
# Copyright 2016-     Robot Framework Foundation
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#    http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import abc
from selenium.webdriver.support.event_firing_webdriver import EventFiringWebElement
from robot.api import logger


class Event:
    @abc.abstractmethod
    def trigger(self, *args, **kwargs):
        pass


def _unwrap_eventfiring_element(element):
    """Workaround for Selenium 3 bug.

    References:
    https://github.com/SeleniumHQ/selenium/issues/7877
    https://github.com/SeleniumHQ/selenium/pull/8348
    https://github.com/SeleniumHQ/selenium/issues/7467
    https://github.com/SeleniumHQ/selenium/issues/6604

    """
    logger.debug("Workaround for Selenium 3 bug.")
    if not isinstance(element, EventFiringWebElement) or selenium_major_version() >= 4:
        return element
    return element.wrapped_element


def selenium_major_version():
    import selenium

    selenium_version = selenium.__version__
    (major, *sub_versions) = selenium_version.split(".")
    return int(major)
